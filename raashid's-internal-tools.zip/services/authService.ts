
import { User } from '../types';

const USERS_KEY = 'omnitool_db_users';
const INVITE_CODES = ['OMNI-FREE-TIER', 'GUEST-ACCESS-2025'];

export class AuthService {
  private getUsers(): Record<string, string> {
    const data = localStorage.getItem(USERS_KEY);
    return data ? JSON.parse(data) : {};
  }

  async login(username: string, password: string): Promise<User | null> {
    // Simulate network delay
    await new Promise(r => setTimeout(r, 800));
    
    const users = this.getUsers();
    if (users[username] === password) {
      return { username, role: 'user' };
    }
    return null;
  }

  async register(username: string, password: string, inviteCode: string): Promise<{success: boolean, message: string}> {
    await new Promise(r => setTimeout(r, 1000));
    
    if (!INVITE_CODES.includes(inviteCode)) {
      return { success: false, message: 'Invalid invite code. Access restricted.' };
    }

    const users = this.getUsers();
    if (users[username]) {
      return { success: false, message: 'Username already taken.' };
    }

    users[username] = password;
    localStorage.setItem(USERS_KEY, JSON.stringify(users));
    return { success: true, message: 'Registration successful!' };
  }
}

export const authService = new AuthService();
