
import { HistoryEntry } from '../types';

const HISTORY_KEY = 'omnitool_system_history';
const MAX_HISTORY = 100;

export class HistoryService {
  getHistory(): HistoryEntry[] {
    const data = localStorage.getItem(HISTORY_KEY);
    return data ? JSON.parse(data) : [];
  }

  logAction(toolId: string, action: string, description: string, metadata?: any) {
    const history = this.getHistory();
    const newEntry: HistoryEntry = {
      id: Math.random().toString(36).substring(2, 11),
      timestamp: Date.now(),
      toolId,
      action,
      description,
      metadata
    };

    const updatedHistory = [newEntry, ...history].slice(0, MAX_HISTORY);
    localStorage.setItem(HISTORY_KEY, JSON.stringify(updatedHistory));
    
    // Dispatch custom event for real-time UI updates if needed
    window.dispatchEvent(new CustomEvent('omnitool_history_update'));
  }

  clearHistory() {
    localStorage.setItem(HISTORY_KEY, JSON.stringify([]));
    window.dispatchEvent(new CustomEvent('omnitool_history_update'));
  }
}

export const historyService = new HistoryService();
