
import { GoogleGenAI } from "@google/genai";

export class GeminiService {
  private ai: GoogleGenAI;

  constructor() {
    this.ai = new GoogleGenAI({ apiKey: process.env.API_KEY || '' });
  }

  async getFileAdvice(query: string) {
    try {
      const response = await this.ai.models.generateContent({
        model: 'gemini-3-flash-preview',
        contents: query,
        config: {
          systemInstruction: `You are an expert file management assistant for OmniTool Cloud. 
          You help users understand video codecs, image formats (PNG vs JPEG vs WebP), and PDF optimization. 
          Keep answers technical yet concise.`,
          temperature: 0.7,
        },
      });
      return response.text;
    } catch (error) {
      console.error('Gemini error:', error);
      return "I'm having trouble connecting to my AI core right now.";
    }
  }
}

export const geminiService = new GeminiService();
