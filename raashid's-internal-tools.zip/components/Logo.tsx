
import React from 'react';
import { useApp } from '../App';

interface LogoProps {
  variant?: 'full' | 'horizontal';
  className?: string;
}

const Logo: React.FC<LogoProps> = ({ variant = 'horizontal', className = '' }) => {
  const { theme } = useApp();
  
  /**
   * Exact mapping from the provided names:
   * Theme 'dark' (Dark background) -> Use Light (white text) logo
   * Theme 'light' (Light background) -> Use Dark (black text) logo
   */
  const getLogoSrc = () => {
    const isDarkBackground = theme === 'dark';
    if (variant === 'full') {
      return isDarkBackground ? 'Full_Light.png' : 'Full_Dark.png';
    } else {
      return isDarkBackground ? 'Horizontal_Light.png' : 'Horizontal_Dark.png';
    }
  };

  return (
    <div className={`flex items-center justify-center select-none ${className}`}>
      <img 
        src={getLogoSrc()} 
        alt="Raashid's Internal Tools" 
        className={variant === 'full' ? 'w-[280px] h-auto' : 'h-8 w-auto'}
        style={{ imageRendering: 'auto' }}
        onError={(e) => {
          // Internal fallback if files are missing from the path
          const target = e.currentTarget;
          target.style.display = 'none';
          const parent = target.parentElement;
          if (parent) {
            parent.innerHTML = `<div class="flex flex-col leading-none ${variant === 'full' ? 'items-center text-center' : ''} dark:text-white text-slate-900">
              <span class="text-[10px] font-medium opacity-60 lowercase tracking-tight">raashid's</span>
              <div class="flex items-center space-x-1">
                <span class="text-sm font-black lowercase tracking-tighter">internal</span>
                <span class="text-sm font-black lowercase tracking-tighter">tools</span>
              </div>
            </div>`;
          }
        }}
      />
    </div>
  );
};

export default Logo;
