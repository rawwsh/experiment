
import React, { useState, useEffect } from 'react';
import { Link, useLocation } from 'react-router-dom';
import { useApp } from '../App';
import Logo from './Logo';

interface NavigationProps {
  onLogout: () => void;
}

const Navigation: React.FC<NavigationProps> = ({ onLogout }) => {
  const { user, theme, toggleTheme } = useApp();
  const location = useLocation();
  const [time, setTime] = useState(new Date());

  useEffect(() => {
    const timer = setInterval(() => setTime(new Date()), 1000);
    return () => clearInterval(timer);
  }, []);

  const navItems = [
    { name: 'Dashboard', path: '/' },
    { name: 'Media', path: '/tools/image' },
    { name: 'Security', path: '/tools/security' },
    { name: 'Dev Hub', path: '/tools/dev' },
    { name: 'AI Engine', path: '/tools/ai' },
  ];

  const formattedTime = time.toLocaleTimeString([], { hour: '2-digit', minute: '2-digit', second: '2-digit', hour12: false });
  const dayName = time.toLocaleDateString([], { weekday: 'short' });

  return (
    <nav className="bg-white/90 dark:bg-slate-900/90 backdrop-blur-md border-b border-slate-200 dark:border-slate-800 sticky top-0 z-50 transition-colors h-14">
      <div className="max-w-7xl mx-auto px-4 h-full">
        <div className="flex justify-between items-center h-full">
          <div className="flex items-center space-x-6">
            <Link to="/" className="hover:opacity-80 transition-opacity">
              <Logo variant="horizontal" />
            </Link>
            
            <div className="hidden md:flex space-x-1">
              {navItems.map((item) => (
                <Link
                  key={item.path}
                  to={item.path}
                  className={`px-3 py-1.5 rounded-lg text-[10px] font-bold uppercase tracking-widest transition-all ${
                    location.pathname === item.path || (item.path !== '/' && location.pathname.startsWith(item.path))
                      ? 'bg-slate-100 dark:bg-slate-800 text-blue-600 dark:text-blue-400'
                      : 'text-slate-600 dark:text-slate-500 hover:text-slate-900 dark:hover:text-white hover:bg-slate-50 dark:hover:bg-slate-800/50'
                  }`}
                >
                  {item.name}
                </Link>
              ))}
            </div>
          </div>

          <div className="flex items-center space-x-3">
            <div className="hidden lg:flex items-center text-[10px] text-slate-400 dark:text-slate-500 font-mono space-x-2 mr-4 pointer-events-none select-none opacity-60">
              <span>{dayName}</span>
              <span className="opacity-30">|</span>
              <span className="tabular-nums tracking-tighter">{formattedTime}</span>
            </div>

            <button
              onClick={toggleTheme}
              className="p-1.5 rounded-lg bg-slate-50 dark:bg-slate-800 text-slate-500 dark:text-slate-400 border border-slate-200 dark:border-slate-700 hover:bg-slate-100 dark:hover:bg-slate-700 transition-colors"
            >
              {theme === 'light' ? (
                <svg className="w-4 h-4" fill="none" viewBox="0 0 24 24" stroke="currentColor"><path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M20.354 15.354A9 9 0 018.646 3.646 9.003 9.003 0 0012 21a9.003 9.003 0 008.354-5.646z" /></svg>
              ) : (
                <svg className="w-4 h-4" fill="none" viewBox="0 0 24 24" stroke="currentColor"><path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M12 3v1m0 16v1m9-9h-1M4 12H3m15.364 6.364l-.707-.707M6.343 6.343l-.707-.707m12.728 0l-.707.707M6.343 17.657l-.707.707M16 12a4 4 0 11-8 0 4 4 0 018 0z" /></svg>
              )}
            </button>

            <div className="h-4 w-px bg-slate-200 dark:bg-slate-800" />

            <div className="hidden sm:flex items-center space-x-2">
              <span className="text-[10px] font-bold text-slate-900 dark:text-slate-200 uppercase tracking-tight">{user?.username}</span>
              <button onClick={onLogout} className="text-[10px] uppercase tracking-wider font-bold text-slate-400 hover:text-red-500 transition-colors">Exit</button>
            </div>
          </div>
        </div>
      </div>
    </nav>
  );
};

export default Navigation;
