
import React, { useState } from 'react';

const DevTool: React.FC = () => {
  const [input, setInput] = useState('');
  const [output, setOutput] = useState('');
  const [error, setError] = useState('');

  const formatJson = () => {
    try {
      const parsed = JSON.parse(input);
      setOutput(JSON.stringify(parsed, null, 2));
      setError('');
    } catch (e) {
      setError('INVALID JSON OBJECT');
    }
  };

  const encodeBase64 = () => {
    try {
      setOutput(btoa(input));
      setError('');
    } catch (e) {
      setError('ENCODING FAULT');
    }
  };

  const decodeBase64 = () => {
    try {
      setOutput(atob(input));
      setError('');
    } catch (e) {
      setError('DECODING FAULT: CHECK PADDING');
    }
  };

  return (
    <div className="max-w-6xl mx-auto space-y-6 animate-in slide-in-from-bottom-4">
      <div className="flex items-center justify-between border-b border-slate-200 dark:border-slate-800 pb-4">
        <div className="flex items-center space-x-3">
          <div className="p-2 bg-amber-100 dark:bg-amber-900/30 rounded-lg text-amber-600 dark:text-amber-400">
            <svg className="w-5 h-5" fill="none" viewBox="0 0 24 24" stroke="currentColor"><path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M10 20l4-16m4 4l4 4-4 4M6 16l-4-4 4-4" /></svg>
          </div>
          <div>
            <h1 className="text-lg font-bold text-slate-900 dark:text-white">Dev Hub</h1>
            <p className="text-[10px] text-slate-500 uppercase font-mono tracking-widest">Utility Workspace // Data Transmutation</p>
          </div>
        </div>
      </div>

      <div className="grid grid-cols-1 lg:grid-cols-12 gap-6 h-[500px]">
        <div className="lg:col-span-5 bg-white dark:bg-slate-900 rounded-xl border border-slate-200 dark:border-slate-800 overflow-hidden flex flex-col shadow-sm">
          <div className="p-3 bg-slate-50 dark:bg-slate-800/50 border-b border-slate-200 dark:border-slate-800 flex justify-between items-center">
            <span className="text-[10px] font-bold text-slate-400 uppercase tracking-widest">Raw Input</span>
            <button onClick={() => setInput('')} className="text-[9px] font-bold text-slate-400 hover:text-red-500 uppercase transition-colors">Clear</button>
          </div>
          <textarea
            value={input}
            onChange={(e) => setInput(e.target.value)}
            placeholder="Paste code or data here..."
            className="flex-1 w-full bg-transparent p-4 font-mono text-xs outline-none resize-none dark:text-white leading-relaxed"
          />
          <div className="p-3 border-t border-slate-200 dark:border-slate-800 grid grid-cols-3 gap-2 bg-slate-50/30 dark:bg-slate-800/20">
            <button onClick={formatJson} className="bg-slate-100 dark:bg-slate-800 hover:bg-slate-200 dark:hover:bg-slate-700 p-2 rounded text-[9px] font-bold uppercase tracking-tight dark:text-slate-300 border border-slate-200 dark:border-slate-700 transition-colors">Format JSON</button>
            <button onClick={encodeBase64} className="bg-slate-100 dark:bg-slate-800 hover:bg-slate-200 dark:hover:bg-slate-700 p-2 rounded text-[9px] font-bold uppercase tracking-tight dark:text-slate-300 border border-slate-200 dark:border-slate-700 transition-colors">to Base64</button>
            <button onClick={decodeBase64} className="bg-slate-100 dark:bg-slate-800 hover:bg-slate-200 dark:hover:bg-slate-700 p-2 rounded text-[9px] font-bold uppercase tracking-tight dark:text-slate-300 border border-slate-200 dark:border-slate-700 transition-colors">from Base64</button>
          </div>
        </div>

        <div className="lg:col-span-7 bg-white dark:bg-slate-900 rounded-xl border border-slate-200 dark:border-slate-800 overflow-hidden flex flex-col shadow-sm">
          <div className="p-3 bg-slate-50 dark:bg-slate-800/50 border-b border-slate-200 dark:border-slate-800">
            <span className="text-[10px] font-bold text-slate-400 uppercase tracking-widest">Processed Result</span>
          </div>
          <div className="flex-1 p-4 font-mono text-xs overflow-auto bg-slate-50/50 dark:bg-slate-950/50 relative">
            {error ? (
              <div className="text-red-500 font-bold uppercase tracking-widest text-[10px] p-2 bg-red-500/10 rounded border border-red-500/20 inline-block">
                Error: {error}
              </div>
            ) : (
              <pre className="dark:text-emerald-400 text-emerald-700 whitespace-pre-wrap">{output || '// Awaiting input...'}</pre>
            )}
            {output && !error && (
              <button 
                onClick={() => navigator.clipboard.writeText(output)}
                className="absolute top-4 right-4 p-2 bg-slate-200 dark:bg-slate-800 rounded-lg hover:bg-blue-500 hover:text-white transition-all group"
              >
                <svg className="w-3.5 h-3.5" fill="none" viewBox="0 0 24 24" stroke="currentColor"><path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M8 5H6a2 2 0 00-2 2v12a2 2 0 002 2h10a2 2 0 002-2v-1M8 5a2 2 0 002 2h2a2 2 0 002-2M8 5a2 2 0 012-2h2a2 2 0 012 2m0 0h2a2 2 0 012 2v3m2 4H10m0 0l3-3m-3 3l3 3" /></svg>
              </button>
            )}
          </div>
        </div>
      </div>
    </div>
  );
};

export default DevTool;
