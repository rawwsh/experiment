
import React, { useState } from 'react';
import { historyService } from '../../services/historyService';

const UrlTool: React.FC = () => {
  const [input, setInput] = useState('');
  const [output, setOutput] = useState('');

  const cleanUrl = () => {
    try {
      const url = new URL(input);
      const paramsToRemove = ['utm_source', 'utm_medium', 'utm_campaign', 'utm_term', 'utm_content', 'fbclid', 'gclid'];
      paramsToRemove.forEach(p => url.searchParams.delete(p));
      const res = url.toString();
      setOutput(res);
      historyService.logAction('url', 'URL_CLEAN', 'Removed trackers from URL');
    } catch (e) {
      setOutput('ERROR: INVALID URL FORMAT');
    }
  };

  const decodeUrl = () => {
    try {
      const res = decodeURIComponent(input);
      setOutput(res);
      historyService.logAction('url', 'URL_DECODE', 'Decoded URL components');
    } catch (e) {
      setOutput('ERROR: DECODE FAULT');
    }
  };

  return (
    <div className="max-w-4xl mx-auto space-y-6 animate-in slide-in-from-bottom-4">
      <div className="flex items-center justify-between border-b border-slate-200 dark:border-slate-800 pb-4">
        <div className="flex items-center space-x-3">
          <div className="p-2 bg-violet-100 dark:bg-violet-900/30 rounded-lg text-violet-600 dark:text-violet-400">
            <svg className="w-5 h-5" fill="none" viewBox="0 0 24 24" stroke="currentColor"><path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M13.828 10.172a4 4 0 00-5.656 0l-4 4a4 4 0 105.656 5.656l1.102-1.101m-.758-4.899a4 4 0 005.656 0l4-4a4 4 0 00-5.656-5.656l-1.1 1.1" /></svg>
          </div>
          <div>
            <h1 className="text-lg font-bold text-slate-900 dark:text-white">URL Utility</h1>
            <p className="text-[10px] text-slate-500 uppercase font-mono tracking-widest">Protocol Engine // Tracking Neutralizer</p>
          </div>
        </div>
      </div>

      <div className="bg-white dark:bg-slate-900 p-6 rounded-xl border border-slate-200 dark:border-slate-800 space-y-4">
        <textarea
          value={input}
          onChange={(e) => setInput(e.target.value)}
          placeholder="Enter long URL or encoded string..."
          className="w-full bg-slate-50 dark:bg-slate-800 border border-slate-200 dark:border-slate-700 rounded-xl px-4 py-3 text-xs outline-none focus:border-violet-500 min-h-[100px] resize-none dark:text-white font-mono"
        />
        
        <div className="grid grid-cols-2 gap-3">
          <button onClick={cleanUrl} className="bg-slate-900 dark:bg-violet-600 text-white font-bold py-3 rounded-lg text-[10px] uppercase tracking-widest hover:opacity-90">Clean Trackers</button>
          <button onClick={decodeUrl} className="bg-slate-100 dark:bg-slate-800 text-slate-900 dark:text-white border border-slate-200 dark:border-slate-700 font-bold py-3 rounded-lg text-[10px] uppercase tracking-widest hover:bg-slate-200 dark:hover:bg-slate-700">Decode Component</button>
        </div>

        {output && (
          <div className="p-4 bg-violet-500/5 border border-violet-500/20 rounded-xl space-y-2">
            <div className="flex justify-between">
              <span className="text-[9px] font-bold text-violet-500 uppercase tracking-widest">Processed Resource</span>
              <button onClick={() => navigator.clipboard.writeText(output)} className="text-[9px] font-bold text-violet-500 uppercase">Copy</button>
            </div>
            <p className="text-xs font-mono break-all dark:text-slate-300">{output}</p>
          </div>
        )}
      </div>
    </div>
  );
};

export default UrlTool;
