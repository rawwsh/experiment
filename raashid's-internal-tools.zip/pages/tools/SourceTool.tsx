
import React, { useState } from 'react';
import { historyService } from '../../services/historyService';

// This is a mapping of the major project files for the explorer
const PROJECT_FILES: Record<string, string> = {
  'App.tsx': `import React, { useState, useEffect, createContext, useContext } from 'react';
import { HashRouter, Routes, Route, Navigate } from 'react-router-dom';
// ... routing logic`,
  'types.ts': `export interface User { ... }
export enum ToolCategory { ... }`,
  'services/historyService.ts': `export class HistoryService { ... }`,
  'services/geminiService.ts': `export class GeminiService { ... }`,
  'components/Navigation.tsx': `const Navigation: React.FC = () => { ... }`,
  'pages/Dashboard.tsx': `const Dashboard: React.FC = () => { ... }`,
  'pages/tools/SourceTool.tsx': `// You are looking at it right now.`
};

const SourceTool: React.FC = () => {
  const [selectedFile, setSelectedFile] = useState('App.tsx');
  const [copied, setCopied] = useState(false);

  const downloadManifest = () => {
    const manifest = {
      project: "Raashid's Internal Tools",
      version: "1.0.0",
      timestamp: new Date().toISOString(),
      files: PROJECT_FILES
    };
    
    const blob = new Blob([JSON.stringify(manifest, null, 2)], { type: 'application/json' });
    const url = URL.createObjectURL(blob);
    const a = document.createElement('a');
    a.href = url;
    a.download = 'project_manifest.json';
    a.click();
    URL.revokeObjectURL(url);
    
    historyService.logAction('system', 'SOURCE_EXPORT', 'Exported project manifest JSON');
  };

  const copyToClipboard = () => {
    navigator.clipboard.writeText(PROJECT_FILES[selectedFile]);
    setCopied(true);
    setTimeout(() => setCopied(false), 2000);
  };

  return (
    <div className="max-w-6xl mx-auto h-[calc(100vh-12rem)] flex flex-col space-y-4 animate-in slide-in-from-bottom-4">
      <div className="flex items-center justify-between border-b border-slate-200 dark:border-slate-800 pb-4">
        <div className="flex items-center space-x-3">
          <div className="p-2 bg-slate-100 dark:bg-slate-800 rounded-lg text-slate-600 dark:text-slate-400 border border-slate-200 dark:border-slate-700">
            <svg className="w-5 h-5" fill="none" viewBox="0 0 24 24" stroke="currentColor"><path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M10 20l4-16m4 4l4 4-4 4M6 16l-4-4 4-4" /></svg>
          </div>
          <div>
            <h1 className="text-lg font-bold text-slate-900 dark:text-white">Source Explorer</h1>
            <p className="text-[10px] text-slate-500 uppercase font-mono tracking-widest">Architectural Map // Version 1.0.0</p>
          </div>
        </div>
        <button 
          onClick={downloadManifest}
          className="bg-blue-600 text-white text-[10px] font-bold uppercase tracking-widest px-4 py-2 rounded-lg hover:bg-blue-500 transition-all flex items-center shadow-lg shadow-blue-600/20"
        >
          <svg className="w-3.5 h-3.5 mr-2" fill="none" viewBox="0 0 24 24" stroke="currentColor"><path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2.5} d="M4 16v1a3 3 0 003 3h10a3 3 0 003-3v-1m-4-4l-4 4m0 0l-4-4m4 4V4" /></svg>
          Download Manifest
        </button>
      </div>

      <div className="flex-1 bg-slate-950 rounded-2xl border border-slate-800 overflow-hidden flex shadow-2xl">
        {/* Sidebar */}
        <div className="w-64 border-r border-slate-800 bg-slate-900/50 flex flex-col">
          <div className="p-4 border-b border-slate-800 bg-slate-900/80">
            <span className="text-[9px] font-bold text-slate-500 uppercase tracking-widest">Project Files</span>
          </div>
          <div className="flex-1 overflow-y-auto p-2 space-y-1">
            {Object.keys(PROJECT_FILES).map((fileName) => (
              <button
                key={fileName}
                onClick={() => setSelectedFile(fileName)}
                className={`w-full text-left px-3 py-2 rounded-lg text-[11px] font-mono transition-all flex items-center ${selectedFile === fileName ? 'bg-blue-500/10 text-blue-400 border border-blue-500/20' : 'text-slate-400 hover:text-white hover:bg-slate-800 border border-transparent'}`}
              >
                <svg className={`w-3 h-3 mr-2 ${selectedFile === fileName ? 'text-blue-400' : 'text-slate-600'}`} fill="none" viewBox="0 0 24 24" stroke="currentColor"><path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M7 21h10a2 2 0 002-2V9.414a1 1 0 00-.293-.707l-5.414-5.414A1 1 0 0012.586 3H7a2 2 0 00-2 2v14a2 2 0 002 2z" /></svg>
                {fileName}
              </button>
            ))}
          </div>
        </div>

        {/* Code View */}
        <div className="flex-1 flex flex-col relative">
          <div className="p-3 bg-slate-900 border-b border-slate-800 flex justify-between items-center">
            <span className="text-[10px] font-mono text-slate-500">/{selectedFile}</span>
            <button 
              onClick={copyToClipboard}
              className="text-[9px] font-bold text-slate-400 hover:text-white uppercase tracking-widest px-2 py-1 bg-slate-800 rounded border border-slate-700 transition-all"
            >
              {copied ? 'Copied!' : 'Copy to Clipboard'}
            </button>
          </div>
          <div className="flex-1 overflow-auto p-6 font-mono text-[11px] leading-relaxed text-slate-300">
            <pre className="whitespace-pre-wrap">{PROJECT_FILES[selectedFile] || '// Code snippet unavailable in explorer view.'}</pre>
          </div>
        </div>
      </div>
    </div>
  );
};

export default SourceTool;
