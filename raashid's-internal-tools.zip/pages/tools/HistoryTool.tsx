
import React, { useState, useEffect } from 'react';
import { historyService } from '../../services/historyService';
import { HistoryEntry } from '../../types';

const HistoryTool: React.FC = () => {
  const [history, setHistory] = useState<HistoryEntry[]>([]);

  const loadHistory = () => {
    setHistory(historyService.getHistory());
  };

  useEffect(() => {
    loadHistory();
    window.addEventListener('omnitool_history_update', loadHistory);
    return () => window.removeEventListener('omnitool_history_update', loadHistory);
  }, []);

  const clearHistory = () => {
    if (confirm('Permanently purge systemic history?')) {
      historyService.clearHistory();
    }
  };

  const formatTime = (ts: number) => {
    return new Date(ts).toLocaleTimeString([], { hour: '2-digit', minute: '2-digit', second: '2-digit', hour12: false });
  };

  const formatDate = (ts: number) => {
    return new Date(ts).toLocaleDateString([], { month: 'short', day: 'numeric' });
  };

  return (
    <div className="max-w-4xl mx-auto space-y-6 animate-in slide-in-from-bottom-4">
      <div className="flex items-center justify-between border-b border-slate-200 dark:border-slate-800 pb-4">
        <div className="flex items-center space-x-3">
          <div className="p-2 bg-slate-100 dark:bg-slate-800 rounded-lg text-slate-600 dark:text-slate-400 border border-slate-200 dark:border-slate-700">
            <svg className="w-5 h-5" fill="none" viewBox="0 0 24 24" stroke="currentColor"><path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M12 8v4l3 3m6-3a9 9 0 11-18 0 9 9 0 0118 0z" /></svg>
          </div>
          <div>
            <h1 className="text-lg font-bold text-slate-900 dark:text-white">System Timeline</h1>
            <p className="text-[10px] text-slate-500 uppercase font-mono tracking-widest">Audit Logs // Session Persistence</p>
          </div>
        </div>
        <button 
          onClick={clearHistory}
          className="text-[10px] font-bold text-red-500 uppercase tracking-widest hover:bg-red-500/10 px-3 py-1.5 rounded transition-all"
        >
          Purge Logs
        </button>
      </div>

      <div className="space-y-4">
        {history.length === 0 ? (
          <div className="bg-white dark:bg-slate-900/50 p-12 rounded-xl border border-slate-200 dark:border-slate-800 border-dashed text-center">
            <p className="text-[10px] font-bold text-slate-500 uppercase tracking-[0.3em]">Timeline Initialized // No Data</p>
          </div>
        ) : (
          history.map((entry) => (
            <div key={entry.id} className="group flex items-start space-x-4 bg-white dark:bg-slate-900 p-4 rounded-xl border border-slate-200 dark:border-slate-800 hover:border-blue-500/50 transition-all">
              <div className="flex flex-col items-center pt-1 min-w-[60px]">
                <span className="text-[10px] font-bold text-slate-400 uppercase mb-0.5">{formatDate(entry.timestamp)}</span>
                <span className="text-[10px] font-mono text-slate-600 dark:text-slate-500">{formatTime(entry.timestamp)}</span>
              </div>
              <div className="flex-1 space-y-1">
                <div className="flex items-center justify-between">
                  <div className="flex items-center space-x-2">
                    <span className="px-1.5 py-0.5 rounded bg-slate-100 dark:bg-slate-800 text-[9px] font-bold text-blue-600 dark:text-blue-400 uppercase tracking-tighter">
                      {entry.toolId}
                    </span>
                    <span className="text-[11px] font-bold text-slate-900 dark:text-white">
                      {entry.action}
                    </span>
                  </div>
                </div>
                <p className="text-xs text-slate-500 dark:text-slate-400 leading-relaxed font-mono">
                  {entry.description}
                </p>
                {entry.metadata && (
                  <div className="mt-2 text-[10px] font-mono text-slate-400 bg-slate-50 dark:bg-slate-800/50 p-2 rounded border border-slate-100 dark:border-slate-700 hidden group-hover:block">
                    {JSON.stringify(entry.metadata, null, 2)}
                  </div>
                )}
              </div>
            </div>
          ))
        )}
      </div>
    </div>
  );
};

export default HistoryTool;
