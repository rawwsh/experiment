
import React, { useState } from 'react';
import { historyService } from '../../services/historyService';

const ConverterTool: React.FC = () => {
  const [value, setValue] = useState<string>('0');
  const [mode, setMode] = useState<'temp' | 'length' | 'weight'>('temp');
  const [fromUnit, setFromUnit] = useState('c');
  const [toUnit, setToUnit] = useState('f');
  const [result, setResult] = useState<string | null>(null);

  const convert = () => {
    const v = parseFloat(value);
    if (isNaN(v)) return;

    let res = 0;
    if (mode === 'temp') {
      if (fromUnit === 'c' && toUnit === 'f') res = (v * 9/5) + 32;
      else if (fromUnit === 'f' && toUnit === 'c') res = (v - 32) * 5/9;
      else if (fromUnit === 'c' && toUnit === 'k') res = v + 273.15;
      else res = v; // Placeholder
    } else if (mode === 'length') {
      if (fromUnit === 'm' && toUnit === 'ft') res = v * 3.28084;
      else if (fromUnit === 'ft' && toUnit === 'm') res = v / 3.28084;
    }
    
    const finalResult = res.toFixed(4);
    setResult(finalResult);
    historyService.logAction('converter', 'UNIT_CONV', `Converted ${v}${fromUnit} to ${finalResult}${toUnit}`);
  };

  return (
    <div className="max-w-4xl mx-auto space-y-6 animate-in slide-in-from-bottom-4">
      <div className="flex items-center justify-between border-b border-slate-200 dark:border-slate-800 pb-4">
        <div className="flex items-center space-x-3">
          <div className="p-2 bg-orange-100 dark:bg-orange-900/30 rounded-lg text-orange-600 dark:text-orange-400">
            <svg className="w-5 h-5" fill="none" viewBox="0 0 24 24" stroke="currentColor"><path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M9 7h6m0 10v-3m-3 3h.01M9 17h.01M9 14h.01M12 14h.01M15 11h.01M12 11h.01M9 11h.01M7 21h10a2 2 0 002-2V5a2 2 0 00-2-2H7a2 2 0 00-2 2v14a2 2 0 002 2z" /></svg>
          </div>
          <div>
            <h1 className="text-lg font-bold text-slate-900 dark:text-white">Unit Converter</h1>
            <p className="text-[10px] text-slate-500 uppercase font-mono tracking-widest">Precision Math Core // Physics Workspace</p>
          </div>
        </div>
      </div>

      <div className="bg-white dark:bg-slate-900 p-8 rounded-xl border border-slate-200 dark:border-slate-800 shadow-sm">
        <div className="flex space-x-2 mb-8 bg-slate-50 dark:bg-slate-800/50 p-1 rounded-xl">
          {['temp', 'length', 'weight'].map((m) => (
            <button
              key={m}
              onClick={() => setMode(m as any)}
              className={`flex-1 py-2 text-[10px] font-bold uppercase tracking-widest rounded-lg transition-all ${mode === m ? 'bg-white dark:bg-slate-700 shadow-sm text-blue-600 dark:text-blue-400' : 'text-slate-400 hover:text-slate-600 dark:hover:text-white'}`}
            >
              {m}
            </button>
          ))}
        </div>

        <div className="grid grid-cols-1 md:grid-cols-12 gap-6 items-center">
          <div className="md:col-span-5 space-y-2">
            <label className="text-[9px] font-bold text-slate-400 uppercase tracking-widest ml-1">Input Value</label>
            <input 
              type="number" value={value} 
              onChange={(e) => setValue(e.target.value)}
              className="w-full bg-slate-50 dark:bg-slate-800 border border-slate-200 dark:border-slate-700 rounded-xl px-4 py-3 text-lg font-mono dark:text-white outline-none focus:border-orange-500" 
            />
          </div>

          <div className="md:col-span-2 flex justify-center pt-6">
            <button onClick={convert} className="p-3 bg-slate-900 dark:bg-slate-800 rounded-full text-white hover:bg-orange-600 transition-colors">
              <svg className="w-5 h-5" fill="none" viewBox="0 0 24 24" stroke="currentColor"><path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M14 5l7 7m0 0l-7 7m7-7H3" /></svg>
            </button>
          </div>

          <div className="md:col-span-5 space-y-2">
            <label className="text-[9px] font-bold text-slate-400 uppercase tracking-widest ml-1">Result</label>
            <div className="w-full bg-slate-100 dark:bg-slate-950/50 border border-slate-200 dark:border-slate-800 rounded-xl px-4 py-3 text-lg font-mono text-orange-600 dark:text-orange-400 h-[54px] flex items-center">
              {result || '---'}
            </div>
          </div>
        </div>

        <div className="mt-8 pt-8 border-t border-slate-100 dark:border-slate-800 grid grid-cols-2 gap-4">
           <div>
             <label className="text-[9px] font-bold text-slate-400 uppercase tracking-widest ml-1 block mb-2">From</label>
             <select 
               value={fromUnit} onChange={(e) => setFromUnit(e.target.value)}
               className="w-full bg-slate-50 dark:bg-slate-800 border border-slate-200 dark:border-slate-700 rounded-lg px-3 py-2 text-xs font-bold uppercase tracking-widest dark:text-white"
             >
               {mode === 'temp' && <><option value="c">Celsius</option><option value="f">Fahrenheit</option><option value="k">Kelvin</option></>}
               {mode === 'length' && <><option value="m">Meters</option><option value="ft">Feet</option></>}
             </select>
           </div>
           <div>
             <label className="text-[9px] font-bold text-slate-400 uppercase tracking-widest ml-1 block mb-2">To</label>
             <select 
               value={toUnit} onChange={(e) => setToUnit(e.target.value)}
               className="w-full bg-slate-50 dark:bg-slate-800 border border-slate-200 dark:border-slate-700 rounded-lg px-3 py-2 text-xs font-bold uppercase tracking-widest dark:text-white"
             >
               {mode === 'temp' && <><option value="f">Fahrenheit</option><option value="c">Celsius</option><option value="k">Kelvin</option></>}
               {mode === 'length' && <><option value="ft">Feet</option><option value="m">Meters</option></>}
             </select>
           </div>
        </div>
      </div>
    </div>
  );
};

export default ConverterTool;
