
import React, { useState, useRef } from 'react';

const ImageTool: React.FC = () => {
  const [selectedImage, setSelectedImage] = useState<File | null>(null);
  const [previewUrl, setPreviewUrl] = useState<string | null>(null);
  const [targetFormat, setTargetFormat] = useState('image/png');
  const [isProcessing, setIsProcessing] = useState(false);
  const canvasRef = useRef<HTMLCanvasElement>(null);

  const handleFileChange = (e: React.ChangeEvent<HTMLInputElement>) => {
    const file = e.target.files?.[0];
    if (file) {
      setSelectedImage(file);
      setPreviewUrl(URL.createObjectURL(file));
    }
  };

  const convertImage = async () => {
    if (!selectedImage || !canvasRef.current) return;
    setIsProcessing(true);

    const img = new Image();
    img.src = previewUrl!;
    
    img.onload = () => {
      const canvas = canvasRef.current!;
      canvas.width = img.width;
      canvas.height = img.height;
      const ctx = canvas.getContext('2d');
      if (!ctx) return;
      
      ctx.drawImage(img, 0, 0);
      
      const dataUrl = canvas.toDataURL(targetFormat);
      const link = document.createElement('a');
      link.download = `raashid_tools_${Date.now()}.${targetFormat.split('/')[1]}`;
      link.href = dataUrl;
      link.click();
      
      setIsProcessing(false);
    };
  };

  return (
    <div className="max-w-6xl mx-auto space-y-6 animate-in slide-in-from-bottom-4 duration-500">
      <div className="flex items-center justify-between border-b border-slate-200 dark:border-slate-800 pb-4">
        <div className="flex items-center space-x-3">
          <div className="p-2 bg-blue-100 dark:bg-blue-900/30 rounded-lg text-blue-600 dark:text-blue-400">
            <svg className="w-5 h-5" fill="none" viewBox="0 0 24 24" stroke="currentColor"><path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M4 16l4.586-4.586a2 2 0 012.828 0L16 16m-2-2l1.586-1.586a2 2 0 012.828 0L20 14m-6-6h.01M6 20h12a2 2 0 002-2V6a2 2 0 00-2-2H6a2 2 0 00-2 2v12a2 2 0 002 2z" /></svg>
          </div>
          <div>
            <h1 className="text-lg font-bold text-slate-900 dark:text-white tracking-tight">Image Service</h1>
            <p className="text-[10px] text-slate-500 uppercase tracking-widest font-mono">Process // Node-Local Environment</p>
          </div>
        </div>
      </div>

      <div className="grid grid-cols-1 lg:grid-cols-12 gap-6">
        <div className="lg:col-span-4 space-y-4">
          <div className="bg-white dark:bg-slate-900 p-6 rounded-xl border border-slate-200 dark:border-slate-800 shadow-sm transition-all group">
            <input type="file" accept="image/*" onChange={handleFileChange} className="hidden" id="image-upload" />
            <label htmlFor="image-upload" className="cursor-pointer flex flex-col items-center justify-center py-4">
              <div className="w-12 h-12 bg-slate-50 dark:bg-slate-800 rounded-lg flex items-center justify-center mb-3 group-hover:bg-blue-50 dark:group-hover:bg-blue-900/10 transition-colors">
                <svg className="w-6 h-6 text-slate-400 group-hover:text-blue-500" fill="none" viewBox="0 0 24 24" stroke="currentColor"><path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M12 4v16m8-8H4" /></svg>
              </div>
              <p className="text-xs font-bold text-slate-700 dark:text-slate-300">Ingest Asset</p>
            </label>
          </div>

          {selectedImage && (
            <div className="bg-white dark:bg-slate-900 p-5 rounded-xl border border-slate-200 dark:border-slate-800 shadow-sm space-y-4">
              <div className="relative">
                <label className="text-[10px] font-bold text-slate-400 uppercase tracking-[0.15em] block mb-1.5 ml-0.5">Target Encoding</label>
                <div className="relative group/select">
                  <select
                    value={targetFormat}
                    onChange={(e) => setTargetFormat(e.target.value)}
                    className="w-full appearance-none pl-4 pr-12 py-2.5 text-xs font-semibold rounded-xl bg-slate-50 dark:bg-slate-800 border border-slate-200 dark:border-slate-700 dark:text-white transition-all outline-none focus:border-blue-500 focus:ring-1 focus:ring-blue-500/20 cursor-pointer"
                  >
                    <option value="image/png">Portable Network Graphics (.png)</option>
                    <option value="image/jpeg">JPEG Standard (.jpg)</option>
                    <option value="image/webp">Google WebP (.webp)</option>
                  </select>
                  {/* Styled Chevron based on screenshot */}
                  <div className="absolute right-4 top-1/2 -translate-y-1/2 pointer-events-none text-slate-400 group-focus-within/select:text-blue-500 transition-colors">
                    <svg className="w-4 h-4" fill="none" viewBox="0 0 24 24" stroke="currentColor" strokeWidth={3}>
                      <path strokeLinecap="round" strokeLinejoin="round" d="M19 9l-7 7-7-7" />
                    </svg>
                  </div>
                </div>
              </div>
              <button
                onClick={convertImage}
                disabled={isProcessing}
                className="w-full bg-slate-900 dark:bg-blue-600 hover:opacity-90 disabled:bg-slate-600 text-white font-bold py-3 rounded-xl transition-all shadow-md shadow-blue-500/10 flex items-center justify-center text-[10px] uppercase tracking-widest"
              >
                {isProcessing ? 'Encoding...' : 'Execute Process'}
              </button>
            </div>
          )}
        </div>

        <div className="lg:col-span-8 bg-slate-100 dark:bg-slate-800/50 rounded-xl overflow-hidden flex items-center justify-center min-h-[350px] border border-slate-200 dark:border-slate-800 relative group shadow-inner">
          {previewUrl ? (
            <img src={previewUrl} alt="Preview" className="max-w-full max-h-[500px] object-contain p-8 drop-shadow-2xl" />
          ) : (
            <div className="text-slate-400 dark:text-slate-600 text-[10px] font-bold uppercase tracking-[0.25em] opacity-30 select-none">
              Buffer Empty
            </div>
          )}
          <div className="absolute bottom-3 left-3 px-2 py-1 rounded bg-black/5 dark:bg-white/5 backdrop-blur-sm border border-black/5 dark:border-white/5">
             <span className="text-[9px] font-mono text-slate-500 dark:text-slate-400 uppercase">Memory: OK</span>
          </div>
        </div>
      </div>
      <canvas ref={canvasRef} className="hidden" />
    </div>
  );
};

export default ImageTool;
