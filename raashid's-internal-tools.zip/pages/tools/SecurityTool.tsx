
import React, { useState } from 'react';
import { historyService } from '../../services/historyService';

const SecurityTool: React.FC = () => {
  const [password, setPassword] = useState('');
  const [passLength, setPassLength] = useState(16);
  const [useSymbols, setUseSymbols] = useState(true);
  const [useNumbers, setUseNumbers] = useState(true);
  
  const [hashInput, setHashInput] = useState('');
  const [hashOutput, setHashOutput] = useState('');
  const [isHashing, setIsHashing] = useState(false);

  const generatePassword = () => {
    let chars = "ABCDEFGHIJKLMNOPQRSTUVWXYZabcdefghijklmnopqrstuvwxyz";
    if (useNumbers) chars += "0123456789";
    if (useSymbols) chars += "!@#$%^&*()_+=-[]{}|;:,.<>?";
    
    let res = "";
    for (let i = 0; i < passLength; i++) {
      res += chars.charAt(Math.floor(Math.random() * chars.length));
    }
    setPassword(res);
    historyService.logAction('security', 'PWD_GEN', `Generated secret (${passLength} chars)`);
  };

  const computeHash = async () => {
    if (!hashInput) return;
    setIsHashing(true);
    const msgBuffer = new TextEncoder().encode(hashInput);
    const hashBuffer = await crypto.subtle.digest('SHA-256', msgBuffer);
    const hashArray = Array.from(new Uint8Array(hashBuffer));
    const hashHex = hashArray.map(b => b.toString(16).padStart(2, '0')).join('');
    setHashOutput(hashHex);
    setIsHashing(false);
    historyService.logAction('security', 'SHA_256', `Computed hash for input (len: ${hashInput.length})`);
  };

  return (
    <div className="max-w-6xl mx-auto space-y-6 animate-in slide-in-from-bottom-4">
      <div className="flex items-center justify-between border-b border-slate-200 dark:border-slate-800 pb-4">
        <div className="flex items-center space-x-3">
          <div className="p-2 bg-emerald-100 dark:bg-emerald-900/30 rounded-lg text-emerald-600 dark:text-emerald-400">
            <svg className="w-5 h-5" fill="none" viewBox="0 0 24 24" stroke="currentColor"><path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M9 12l2 2 4-4m5.618-4.016A11.955 11.955 0 0112 2.944a11.955 11.955 0 01-8.618 3.04A12.02 12.02 0 003 9c0 5.591 3.824 10.29 9 11.622 5.176-1.332 9-6.03 9-11.622 0-1.042-.133-2.052-.382-3.016z" /></svg>
          </div>
          <div>
            <h1 className="text-lg font-bold text-slate-900 dark:text-white">Security Hub</h1>
            <p className="text-[10px] text-slate-500 uppercase font-mono tracking-widest">Entropy Core // Client-Side Protected</p>
          </div>
        </div>
      </div>

      <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
        <div className="bg-white dark:bg-slate-900 p-6 rounded-xl border border-slate-200 dark:border-slate-800 space-y-6 shadow-sm">
          <h3 className="text-xs font-bold text-slate-400 uppercase tracking-widest border-l-2 border-emerald-500 pl-2">Secret Architect</h3>
          
          <div className="space-y-4">
            <div className="flex flex-col space-y-2">
              <div className="flex justify-between text-[10px] font-bold text-slate-500 uppercase tracking-widest">
                <span>Length</span>
                <span>{passLength}</span>
              </div>
              <input 
                type="range" min="8" max="64" value={passLength} 
                onChange={(e) => setPassLength(parseInt(e.target.value))}
                className="w-full h-1.5 bg-slate-200 dark:bg-slate-800 rounded-lg appearance-none cursor-pointer accent-emerald-500" 
              />
            </div>

            <div className="grid grid-cols-2 gap-3">
              <button 
                onClick={() => setUseNumbers(!useNumbers)}
                className={`p-3 rounded-xl border text-[10px] font-bold uppercase tracking-widest transition-all ${useNumbers ? 'bg-emerald-500/10 border-emerald-500 text-emerald-500' : 'bg-slate-50 dark:bg-slate-800 border-slate-200 dark:border-slate-700 text-slate-400'}`}
              >
                Numbers (0-9)
              </button>
              <button 
                onClick={() => setUseSymbols(!useSymbols)}
                className={`p-3 rounded-xl border text-[10px] font-bold uppercase tracking-widest transition-all ${useSymbols ? 'bg-emerald-500/10 border-emerald-500 text-emerald-500' : 'bg-slate-50 dark:bg-slate-800 border-slate-200 dark:border-slate-700 text-slate-400'}`}
              >
                Symbols (!@#)
              </button>
            </div>

            <div className="bg-slate-50 dark:bg-slate-800 p-4 rounded-xl font-mono text-sm break-all text-emerald-600 dark:text-emerald-400 border border-slate-200 dark:border-slate-700 min-h-[60px] flex items-center justify-center relative group">
              {password || 'Config Pending'}
              {password && (
                <button 
                  onClick={() => {
                    navigator.clipboard.writeText(password);
                    historyService.logAction('security', 'PWD_COPY', 'Copied generated secret to clipboard');
                  }}
                  className="absolute right-3 p-1.5 rounded-lg bg-emerald-500/20 text-emerald-500 hover:bg-emerald-500 hover:text-white transition-all opacity-0 group-hover:opacity-100"
                >
                  <svg className="w-3 h-3" fill="none" viewBox="0 0 24 24" stroke="currentColor"><path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M8 16H6a2 2 0 01-2-2V6a2 2 0 012-2h8a2 2 0 012 2v2m-6 12h8a2 2 0 002-2v-8a2 2 0 00-2-2h-8a2 2 0 00-2 2v8a2 2 0 002 2z" /></svg>
                </button>
              )}
            </div>
            
            <button
              onClick={generatePassword}
              className="w-full bg-slate-900 dark:bg-emerald-600 text-white font-bold py-4 rounded-xl text-[10px] uppercase tracking-[0.2em] hover:opacity-90 transition-all shadow-lg shadow-emerald-500/10"
            >
              Execute Generator
            </button>
          </div>
        </div>

        <div className="bg-white dark:bg-slate-900 p-6 rounded-xl border border-slate-200 dark:border-slate-800 space-y-6 shadow-sm">
          <h3 className="text-xs font-bold text-slate-400 uppercase tracking-widest border-l-2 border-emerald-500 pl-2">Integrity Hash (SHA-256)</h3>
          <div className="space-y-4">
            <textarea
              value={hashInput}
              onChange={(e) => setHashInput(e.target.value)}
              placeholder="Paste message for hashing..."
              className="w-full bg-slate-50 dark:bg-slate-800 border border-slate-200 dark:border-slate-700 rounded-xl px-4 py-3 text-xs outline-none focus:border-emerald-500 min-h-[120px] resize-none dark:text-white leading-relaxed"
            />
            {hashOutput && (
              <div className="p-3 bg-emerald-500/5 border border-emerald-500/20 rounded-lg">
                <div className="flex justify-between mb-1">
                  <span className="text-[9px] font-bold text-emerald-500 uppercase tracking-tighter">Hex Result</span>
                  <button onClick={() => navigator.clipboard.writeText(hashOutput)} className="text-[9px] text-emerald-500 font-bold uppercase">Copy</button>
                </div>
                <p className="font-mono text-[10px] break-all dark:text-slate-300 leading-tight">{hashOutput}</p>
              </div>
            )}
            <button
              onClick={computeHash}
              disabled={isHashing || !hashInput}
              className="w-full bg-slate-900 dark:bg-emerald-600 text-white font-bold py-4 rounded-xl text-[10px] uppercase tracking-[0.2em] hover:opacity-90 disabled:opacity-50 transition-all"
            >
              {isHashing ? 'Computing Engine...' : 'Generate System Hash'}
            </button>
          </div>
        </div>
      </div>
    </div>
  );
};

export default SecurityTool;
