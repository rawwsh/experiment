
import React, { useState } from 'react';

const VideoTool: React.FC = () => {
  const [selectedVideo, setSelectedVideo] = useState<File | null>(null);
  const [metadata, setMetadata] = useState<{ size: string; type: string; name: string } | null>(null);

  const handleFileChange = (e: React.ChangeEvent<HTMLInputElement>) => {
    const file = e.target.files?.[0];
    if (file) {
      setSelectedVideo(file);
      setMetadata({
        size: (file.size / (1024 * 1024)).toFixed(2) + ' MB',
        type: file.type,
        name: file.name
      });
    }
  };

  return (
    <div className="max-w-6xl mx-auto space-y-6 animate-in slide-in-from-bottom-4 duration-500">
      <div className="flex items-center justify-between border-b border-slate-200 dark:border-slate-800 pb-4">
        <div className="flex items-center space-x-3">
          <div className="p-2 bg-indigo-100 dark:bg-indigo-900/30 rounded-lg text-indigo-600 dark:text-indigo-400">
            <svg className="w-5 h-5" fill="none" viewBox="0 0 24 24" stroke="currentColor"><path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M15 10l4.553-2.276A1 1 0 0121 8.618v6.764a1 1 0 01-1.447.894L15 14M5 18h8a2 2 0 002-2V8a2 2 0 00-2-2H5a2 2 0 00-2 2v8a2 2 0 002 2z" /></svg>
          </div>
          <div>
            <h1 className="text-lg font-bold text-slate-900 dark:text-white">Video Toolbox</h1>
            <p className="text-xs text-slate-500">Server-side processing // FFmpeg Engine</p>
          </div>
        </div>
      </div>

      <div className="bg-white dark:bg-slate-900 p-6 rounded-xl border border-slate-200 dark:border-slate-800 shadow-sm transition-colors">
        {!selectedVideo ? (
          <div className="py-12 flex flex-col items-center border-2 border-dashed border-slate-100 dark:border-slate-800 rounded-xl group hover:border-indigo-400 transition-all">
            <input type="file" accept="video/*" onChange={handleFileChange} className="hidden" id="video-upload" />
            <label htmlFor="video-upload" className="cursor-pointer text-center">
              <div className="w-16 h-16 bg-indigo-50 dark:bg-indigo-900/20 rounded-xl flex items-center justify-center mx-auto mb-4 group-hover:scale-105 transition-transform">
                <svg className="w-8 h-8 text-indigo-500" fill="none" viewBox="0 0 24 24" stroke="currentColor"><path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M7 16a4 4 0 01-.88-7.903A5 5 0 1115.9 6L16 6a5 5 0 011 9.9M15 13l-3-3m0 0l-3 3m3-3v12" /></svg>
              </div>
              <h3 className="text-sm font-bold text-slate-900 dark:text-white">Ingest Video</h3>
              <p className="text-[10px] text-slate-500 mt-1 uppercase tracking-widest">Supports MP4, MOV, WebM</p>
            </label>
          </div>
        ) : (
          <div className="space-y-6">
            <div className="flex items-center justify-between p-4 bg-slate-50 dark:bg-slate-800 rounded-xl border border-slate-100 dark:border-slate-700">
              <div className="flex items-center space-x-4">
                <div className="w-10 h-10 bg-indigo-600 rounded-lg flex items-center justify-center text-white">
                  <svg className="w-5 h-5" fill="none" viewBox="0 0 24 24" stroke="currentColor"><path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M14.752 11.168l-3.197-2.132A1 1 0 0010 9.87v4.263a1 1 0 001.555.832l3.197-2.132a1 1 0 000-1.664z" /></svg>
                </div>
                <div className="max-w-xs md:max-w-md">
                  <h3 className="text-sm font-bold text-slate-900 dark:text-white truncate">{metadata?.name}</h3>
                  <p className="text-[10px] text-slate-500 font-mono">{metadata?.size} // {metadata?.type}</p>
                </div>
              </div>
              <button onClick={() => setSelectedVideo(null)} className="text-slate-400 hover:text-red-500">
                <svg className="w-5 h-5" fill="none" viewBox="0 0 24 24" stroke="currentColor"><path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M6 18L18 6M6 6l12 12" /></svg>
              </button>
            </div>

            <div className="grid grid-cols-1 sm:grid-cols-2 gap-3">
              <button className="flex flex-col items-center p-4 bg-white dark:bg-slate-800 border border-slate-200 dark:border-slate-700 rounded-xl hover:border-indigo-500 transition-all group">
                <span className="text-xs font-bold text-slate-900 dark:text-white">Transcode</span>
                <span className="text-[9px] text-slate-500 mt-1 uppercase">H.264 Optimized</span>
              </button>
              <button className="flex flex-col items-center p-4 bg-white dark:bg-slate-800 border border-slate-200 dark:border-slate-700 rounded-xl hover:border-indigo-500 transition-all group">
                <span className="text-xs font-bold text-slate-900 dark:text-white">Remux</span>
                <span className="text-[9px] text-slate-500 mt-1 uppercase">Change Container</span>
              </button>
            </div>

            <div className="p-3 bg-amber-500/5 rounded-lg border border-amber-500/10 flex space-x-3 items-start">
              <svg className="w-4 h-4 text-amber-500 mt-0.5" fill="none" viewBox="0 0 24 24" stroke="currentColor"><path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M13 16h-1v-4h-1m1-4h.01M21 12a9 9 0 11-18 0 9 9 0 0118 0z" /></svg>
              <p className="text-[10px] text-amber-600 dark:text-amber-500 font-medium">
                Note: Oracle VM processing queue is shared. Processing time scales with file size.
              </p>
            </div>
          </div>
        )}
      </div>
    </div>
  );
};

export default VideoTool;
