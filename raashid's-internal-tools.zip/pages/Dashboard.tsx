
import React from 'react';
import { Link } from 'react-router-dom';
import { ToolCategory } from '../types';

const Dashboard: React.FC = () => {
  const tools = [
    {
      id: 'image',
      name: 'Image Service',
      description: 'Format conversion, resizing & WebP optimization.',
      category: ToolCategory.IMAGE,
      path: '/tools/image',
      color: 'blue'
    },
    {
      id: 'video',
      name: 'Video Service',
      description: 'Transcoding, compression & metadata tools.',
      category: ToolCategory.VIDEO,
      path: '/tools/video',
      color: 'indigo'
    },
    {
      id: 'pdf',
      name: 'PDF Service',
      description: 'Merge, split, and compress document assets.',
      category: ToolCategory.PDF,
      path: '/tools/pdf',
      color: 'rose'
    },
    {
      id: 'security',
      name: 'Security Hub',
      description: 'Entropy generator, hashing & secret management.',
      category: ToolCategory.SECURITY,
      path: '/tools/security',
      color: 'emerald'
    },
    {
      id: 'url',
      name: 'URL Utility',
      description: 'Clean trackers, encode, and systemic short links.',
      category: ToolCategory.UTILITY,
      path: '/tools/url',
      color: 'violet'
    },
    {
      id: 'dev',
      name: 'Dev Hub',
      description: 'JSON, Base64 & systemic transformation tools.',
      category: ToolCategory.UTILITY,
      path: '/tools/dev',
      color: 'amber'
    },
    {
      id: 'source',
      name: 'Source Explorer',
      description: 'Browse app architecture and download project files.',
      category: ToolCategory.SYSTEM,
      path: '/tools/source',
      color: 'slate'
    },
    {
      id: 'ai',
      name: 'Logic Engine',
      description: 'AI-powered code debugging & technical advice.',
      category: ToolCategory.AI,
      path: '/tools/ai',
      color: 'cyan'
    }
  ];

  return (
    <div className="space-y-8 animate-in fade-in duration-500">
      <header className="flex items-center justify-between border-b border-slate-200 dark:border-slate-800 pb-4">
        <div>
          <h1 className="text-xl font-bold text-slate-900 dark:text-white tracking-tight">System Workspace</h1>
          <p className="text-[10px] text-slate-500 dark:text-slate-500 font-mono uppercase tracking-widest">Oracle Cloud Cluster // Node-01-Active</p>
        </div>
        <div className="flex items-center space-x-3">
          <Link to="/tools/history" className="px-3 py-1.5 rounded-lg bg-slate-100 dark:bg-slate-800 text-[10px] font-bold text-slate-600 dark:text-slate-400 uppercase tracking-widest border border-slate-200 dark:border-slate-700 hover:border-blue-500 transition-all">
            View Timeline
          </Link>
          <span className="px-2 py-1 rounded bg-emerald-500/10 text-emerald-600 dark:text-emerald-400 text-[9px] font-bold uppercase tracking-widest border border-emerald-500/20 flex items-center">
            <span className="w-1.5 h-1.5 rounded-full bg-emerald-500 mr-2 animate-pulse"></span>
            Stable
          </span>
        </div>
      </header>

      <section className="space-y-4">
        <h2 className="text-xs font-bold text-slate-400 uppercase tracking-widest border-l-2 border-blue-600 pl-2 ml-1">Internal Services</h2>
        <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-3 xl:grid-cols-4 gap-4">
          {tools.map((tool) => (
            <Link
              key={tool.id}
              to={tool.path}
              className="group bg-white dark:bg-slate-900/50 p-5 rounded-xl border border-slate-200 dark:border-slate-800 hover:border-blue-500/50 dark:hover:border-blue-500/50 hover:shadow-lg hover:shadow-blue-500/5 transition-all duration-300 relative overflow-hidden"
            >
              <div className="flex items-center justify-between mb-4">
                <div className={`w-10 h-10 bg-slate-50 dark:bg-slate-800 rounded-lg flex items-center justify-center group-hover:scale-105 transition-transform`}>
                  <div className={`w-2 h-2 rounded-full bg-${tool.color}-500 shadow-[0_0_10px_rgba(var(--tw-color-${tool.color}-500),0.5)]`}></div>
                </div>
                <span className="text-[9px] font-bold text-slate-400 uppercase tracking-tighter">{tool.category}</span>
              </div>
              <h3 className="text-sm font-bold text-slate-900 dark:text-white mb-1">{tool.name}</h3>
              <p className="text-xs text-slate-500 dark:text-slate-400 leading-relaxed mb-4 line-clamp-2">{tool.description}</p>
              <div className="flex items-center text-[10px] text-blue-600 dark:text-blue-400 font-bold uppercase tracking-widest opacity-0 group-hover:opacity-100 transition-opacity">
                Execute Process
                <svg className="w-3 h-3 ml-1" fill="none" viewBox="0 0 24 24" stroke="currentColor"><path strokeLinecap="round" strokeLinejoin="round" strokeWidth={3} d="M13 7l5 5m0 0l-5 5m5-5H6" /></svg>
              </div>
            </Link>
          ))}
        </div>
      </section>

      <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
        <div className="p-6 bg-slate-900 rounded-2xl border border-slate-800">
           <h3 className="text-[10px] font-bold text-slate-500 uppercase tracking-widest mb-4">Node Health</h3>
           <div className="space-y-4">
             <div className="flex justify-between items-center">
               <span className="text-xs text-slate-400">Source Integrity</span>
               <span className="text-xs font-mono text-emerald-400">Verified</span>
             </div>
             <div className="w-full h-1 bg-slate-800 rounded-full overflow-hidden">
               <div className="w-full h-full bg-emerald-500"></div>
             </div>
             <div className="flex justify-between items-center">
               <span className="text-xs text-slate-400">Memory Cluster</span>
               <span className="text-xs font-mono text-blue-400">512MB / 1GB</span>
             </div>
             <div className="w-full h-1 bg-slate-800 rounded-full overflow-hidden">
               <div className="w-[50%] h-full bg-blue-500"></div>
             </div>
           </div>
        </div>

        <div className="p-6 bg-white dark:bg-slate-900/40 rounded-2xl border border-slate-200 dark:border-slate-800 flex flex-col justify-between">
           <div>
             <h3 className="text-[10px] font-bold text-slate-500 uppercase tracking-widest mb-2">Automated Backups</h3>
             <p className="text-xs text-slate-600 dark:text-slate-400">Oracle Cloud Block Volume backups are active. Your local session is synchronized with the primary node database.</p>
           </div>
           <div className="flex items-center space-x-3 mt-4">
              <span className="text-[10px] font-mono text-slate-400">Last Synced: Just now</span>
           </div>
        </div>
      </div>
    </div>
  );
};

export default Dashboard;
